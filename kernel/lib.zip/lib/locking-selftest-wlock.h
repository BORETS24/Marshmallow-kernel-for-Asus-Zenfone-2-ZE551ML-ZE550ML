#undef LOCK
#define LOCK		WL

#undef UNLOCK
#define UNLOCK		WU

#undef RLOCK
#define RLOCK		RL

#undef WLOCK
#define WLOCK		WL

#undef INIT
#define INIT		RWI
